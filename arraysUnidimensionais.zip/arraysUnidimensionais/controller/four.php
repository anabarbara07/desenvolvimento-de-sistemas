<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

<style>
    .nav {
        background-color: black;
    }

    body {
      background-color: #DCDCDC;
    }
    </style>

<ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active text-danger" aria-current="page" href="index.php">Início</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="one.php">One</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="two.php">Two</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="three.php">Three</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-light" href="four.php">Four</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="five.php">Five</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="six.php">Six</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="seven.php">Seven</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="eight.php">Eight</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="nine.php">Nine</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="ten.php">Ten</a>
  </li>

</ul>

    <center>
    <div class="container mt-5">
        <div class="card shadow-lg p-4 bg-light rounded">
            <h1 class="card-title text-center">Exercicio 4!</h1>
        <?php 
echo '<br>';
echo 'Crie um array unidimensional com 10 strings. Permita que o usuário insira uma string por meio de um formulário web e verifique se ela está presente no array. Exiba uma mensagem informando se a string foi encontrada ou não. <br>';
echo '<br>';?>

    <form action="" method="POST">
            <br>
            <label for="stringU" class="form-label">Entre com uma string:</label>
            <input type="text" id="stringU" name="stringU" class="form-control" required><br>
        
        <button type="submit" class="btn btn-danger">Verificar</button>
    </form>

    <?php


    $stringList = array('analinda', 'eu', 'sim', 'nao');

    if ($_POST) {
        $stringU = $_POST['stringU'];
        $encontrou = false;

        foreach ($stringList as $value) {
            if ($value == $stringU) {
                $encontrou = true;
                break;
            }
        }

        if ($encontrou) {
            echo 'String encontrada!';
        } else {
            echo 'String não encontrada!';
        }
    }
    ?>

</div>
  </div>
  </div>
    </center>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>