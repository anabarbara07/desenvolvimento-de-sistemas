<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>

<style>
    .nav {
        background-color: black;

    }
    
    </style>

<ul class="nav justify-content-center ">
  <li class="nav-item">
    <a class="nav-link active text-danger" aria-current="page" href="index.php">Início</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="one.php">One</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="two.php">Two</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="three.php">Three</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="four.php">Four</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="five.php">Five</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="six.php">Six</a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-danger" href="seven.php">Seven</a>
  </li>

</ul>

<center>

    <?php
    $number = array('8','5','24','4','70','2','32','7','99','6');
    $maior = 0;
    $menor = 100;

    for ($i = 0; $i < count($number); $i++) {
        if ($number[$i] > $maior)
        {
            $maior = $number[$i];
        }
        if ($number[$i] < $menor)
        {
            $menor = $number[$i];
        }
    }
    echo '<br>';
    echo 'Crie um array unidimensional com 10 números inteiros. Encontre e exiba o menor e o maior número do array.';
    echo '<br><br>';
    foreach ($number as $key => $value) {
        echo $value .'  ';
    }
    echo '<br>Maior: ' . $maior;
    echo '<br>Menor: ' . $menor;
    ?>

</center>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>