<?php
$carros = array('Marca'=>'Ford', 'Modelo'=>'Ford Ka', 'Ano'=>1995); 

foreach ($carros as $key => $value) {
    echo $value.'<br>';
}

echo $carros['Marca'];
?>