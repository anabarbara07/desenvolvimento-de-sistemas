<?php

if($_POST){
    $nome = $_POST['nome'];
    $marcalist = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $cor = $_POST['cor'];

    echo 'Nome:' .$nome;
    echo '<br>';

    if(isset($marcalist)){
        foreach ($marcalist as $key => $value){
            echo '<p> Marca:' .$value;
        }
    }
    echo '<p> Modelo: ' .$modelo;
    echo '<p> Cor: ' .$cor;
}


?>