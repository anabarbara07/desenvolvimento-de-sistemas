<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
    <!--
        //Uso para subscrever o css do bootstrap 
        <style>
        .container{
            border: 1px solid red;
        }
        
        .container-fluid{
            border: 1px solid red;
        }
    </style>-->
</head>

<body>
    <div class="container pt-5 my-5 border bg-secondary">
        
        <center><h1>Cadastro de automóvel</h1></center>
        <center><p class="text-bg-danger">Cadastro de carros para todas as marcas.</p></center>
        <p class="h1">Marcas</p>
        <div class="alert alert-danger">
            <b>Atenção:</b> É necessário cadastrar todas as marcas.
        </div>
        <form method="post" action="controller/carrosController.php"  > <!--class="was-validated"-->
            <div class="mb-3 mt-3">
                <label for="nome" class="form-label">Nome:</label>
                <input type="text" class="form-control" id="nome" name="nome" placeholder="Insira um nome para seu automóvel">
                <div class="valid-feedback">OK</div>
                <div class="invalid-feedback">Preencha este campo.</div>
            </div>
            <div class="mb-3 mt-3">
                <label for="marca" class="form-label">Marcas:</label>
                <div class="form-check">
                    <input type="checkbox" class="form-check-input" name="marca[]" value="Valor 1">
                    <label class="form-check-label">Valor 1</label>
                </div>
                <div class="form-check">
                    <input type="checkbox" class="form-check-input" name="marca[]" value="Valor 2">
                    <label class="form-check-label">Valor 2</label>
                </div>
                <div class="form-check">
                    <input type="checkbox" class="form-check-input" name="marca[]" value="Valor 3">
                    <label class="form-check-label">Valor 3</label>
                </div>
            </div>
            <div class="mb-3 mt-3">
              <label for="modelo" class="form-label">Modelo:</label>
                <select id="modelo" name="modelo" class="form-select">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                </select>
            </div>
            <div class="mb-3 mt-3"> <!--tamanho pra celular e tablet-->
            <label for="cor" class="form-label">Cor:</label>
             <div class="form-check">    
                <input type="radio" class="form-check-input" id="cor" name="cor" value="branco">
                <label class="form-check-label" for="cor">Branco</label>
             </div>
            </div>
            <div class="mb-3 mt-3"> <!--tamanho pra celular e tablet-->
             <div class="form-check">
                <input type="radio" class="form-check-input" id="cor" name="cor" value="cinza">
                <label class="form-check-label" for="cor2">Cinza</label>
             </div>
             <div class="form-check">
                <input type="radio" class="form-check-input" id="cor" name="cor" value="preto">
                <label class="form-check-label" for="cor3">Preto</label>
             </div>
             </div>
             <div class="mb-3 mt-3"> <!--tamanho pra celular e tablet-->
                <input type="submit" value="Escolher carro" class="border border-dark btn btn-danger">
                <a href="a" class="border border-dark btn btn-danger">Clique aqui</a>
             </div>

        </form>
    </div>
</body>

</html>