<?php
session_start();

$projetos = isset($_SESSION['projetosFiltrados']) ? $_SESSION['projetosFiltrados'] : array(
    array(
        'status' => 'Concluido',
        'nome' => 'Quadra de Padel'
    ),
    array(
        'status' => 'Em andamento',
        'nome' => 'Quadra de Tenis'
    ),
    array(
        'status' => 'Em andamento',
        'nome' => 'Futsabão'
    ),
    array(
        'status' => 'Concluido',
        'nome' => 'Cinema'
    ),
    array(
        'status' => 'A começar',
        'nome' => 'Quadra de Pickeball'
    ),
);
?>

<!doctype html>
<html lang="en">
    <head>
        <title>Projetos</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    </head>
    <body>
        <header>
            <!-- Navbar -->
        </header>
        <main class="container">
            <h1 class="mt-5 text-center">Gerenciamento de Projetos</h1>
            
            <form method="post" action="./controller/projetosController.php" class="text-center my-4">
                <label for="status">Filtrar por status: </label><br>
                <select name="status" id="status" class="form-select w-25 mx-auto">
                    <option value="todos">Todos</option>
                    <option value="Concluido">Concluído</option>
                    <option value="Em andamento">Em andamento</option>
                    <option value="A começar">A começar</option>
                </select><br>
                <input class="btn btn-danger" type="submit" value="Filtrar" />
            </form>

            <div class="project-list">
                <?php if (($projetos)): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($projetos as $projeto): ?>
                                <tr>
                                    <td><?php echo ($projeto['nome']); ?></td>
                                    <td><?php echo ($projeto['status']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            
                            
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-center">Nenhum projeto encontrado.</p>
                <?php endif; ?>
            </div>

                        <center>
                            <form action="tarefas.php" method="post">
                              <button type="submit" class="btn btn-danger">Ver Tarefas</button>
                            </form><br>
                        </center>

            <div class="text-center">
                <a class="btn btn-danger" href="./index.php">Voltar</a>
            </div>
        </main>
        <footer class="mt-5">
            <!-- Footer -->
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
