<?php
session_start();

$projetos = array(
    array('id' => 1, 'nome' => 'Quadra de Pickeball'),
    array('id' => 2, 'nome' => 'Quadra de Tênis'),
    array('id' => 3, 'nome' => 'Futsabão')
);

$tarefas = array(
    array('nome' => 'Construção da quadra', 'descricao' => 'Iniciar pavimento inicial da quadra', 'status' => 'Pendente', 'projetoId' => 1, 'userId' => 1),
    array('nome' => 'Instalar iluminação', 'descricao' => 'Instalar novas luzes', 'status' => 'Em andamento', 'projetoId' => 2, 'userId' => 2),
    array('nome' => 'Inflar lona', 'descricao' => 'Inflar com ajuda de equipamentos a quadra', 'status' => 'Em andamento', 'projetoId' => 3, 'userId' => 1)
);

function usuariosLoadNameByID($id) {
    $users = array(
        array('id' => 1, 'nome' => 'Ana'),
        array('id' => 2, 'nome' => 'Scooby')
    );
    
    foreach ($users as $user) {
        if ($user['id'] == $id) {
            return $user['nome'];
        }
    }
    return 'Desconhecido';
}

function projetosLoadNameByID($projetoId) {
    global $projetos;
    foreach ($projetos as $projeto) {
        if ($projeto['id'] == $projetoId) {
            return $projeto['nome'];
        }
    }
    return 'Desconhecido';
}

function tarefasLoadAll() {
    global $tarefas;
    return $tarefas;
}

$tarefasFiltradas = tarefasLoadAll();
?>

<!doctype html>
<html lang="en">
    <head>
        <title>Tarefas</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    </head>

    <body>
        <header>
            <!-- Navbar -->
        </header>
        <main>
        <center><br><br>
        <h1>Tarefas de Todos os Projetos</h1>

        <?php if (!empty($tarefasFiltradas)) { ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nome da Tarefa</th>
                        <th>Descrição</th>
                        <th>Status</th>
                        <th>Projeto</th>
                        <th>Usuário Responsável</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tarefasFiltradas as $tarefa) { ?>
                        <tr>
                            <td><?php echo $tarefa['nome']; ?></td>
                            <td><?php echo $tarefa['descricao']; ?></td>
                            <td><?php echo $tarefa['status']; ?></td>
                            <td><?php echo projetosLoadNameByID($tarefa['projetoId']); ?></td>
                            <td><?php echo usuariosLoadNameByID($tarefa['userId']); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <p>Nenhuma tarefa encontrada.</p>
        <?php } ?>
        
        <a class="btn btn-danger" href="../gerProjetos.php">Voltar para Projetos</a>
        </center>  
        </main>
    </body>
</html>
