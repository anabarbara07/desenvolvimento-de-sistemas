<?php 

$users = array(
    array(
        'email' => 'a@b.com',
        'nome' => 'ana',
        'senha' => '123',
        'id' => '1'
    ),
    array(
        'email' => 'z@z.com',
        'nome' => 'scooby',
        'senha' => '234',
        'id' => '2'
    )
);

$email = $_POST['email'];
$senha = $_POST['senha'];

$validauser = null;

foreach($users as $user) {
    if($user['email'] === $email && $user['senha'] === $senha){
        $validauser = $user;
        break;
    }
}

if ($validauser){
    $_SESSION['user'] = $validauser;
    header("Location: ../gerProjetos.php");
} else {
    echo 'Dados incorretos. Tente novamente.';
    header("Location: ../index.php");
}
?>

<?php
function usuariosLoadNameByID($id) {
    global $users;
    foreach ($users as $user) {
        if ($user['id'] === $id) {
            return $user['nome'];
        }
    }
    return 'Desconhecido'; 
}
?>
