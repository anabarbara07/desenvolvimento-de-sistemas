<?php
session_start();

$projetos = array(
    array(
        'status' => 'Concluido',
        'nome' => 'Quadra de Padel'
    ),
    array(
        'status' => 'Em andamento',
        'nome' => 'Quadra de Tenis'
    ),
    array(
        'status' => 'Em andamento',
        'nome' => 'Futsabão'
    ),
    array(
        'status' => 'Concluido',
        'nome' => 'Cinema'
    ),
    array(
        'status' => 'A começar',
        'nome' => 'Quadra de Pickeball'
    ),
);

function projetosLoadAll() {
    global $projetos;
    return $projetos;
}

function projetosLoadByStatusId($status) {
    global $projetos;
    $resultados = array_filter($projetos, function ($projeto) use ($status) {
        return $projeto['status'] === $status;
    });
    return $resultados;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $statusSelecionado = $_POST['status'];
    if ($statusSelecionado === 'todos') {
        $projetosFiltrados = projetosLoadAll();
    } else {
        $projetosFiltrados = projetosLoadByStatusId($statusSelecionado);
    }
    $_SESSION['projetosFiltrados'] = $projetosFiltrados;
    header("Location: ../gerProjetos.php");
    exit;
}
?>


