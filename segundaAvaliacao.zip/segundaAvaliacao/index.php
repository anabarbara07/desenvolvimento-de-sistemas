<!doctype html>
<html lang="en">
    <head>
        <title>Login</title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />

        <!-- Bootstrap CSS v5.2.1 -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
        /><script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        ></script>

    </head>

    <body>
        <header>
            <!-- place navbar here -->
        </header>
        <main>
            <form method="post" action="./controller/usuarioController.php">
            <div class="container mt-5 content-align-center">
        <div >
                <h1>Login</h1><br>
                <label for="email">E-mail: </label>
                    <input type="email" name="email" id="email" placeholder="Informe seu e-mail aqui." required>
                    <br><br>
                
                <label for="senha">Senha:</label>
                    <input type="password" name="senha" id="senha" required>
                
                <input class="btn btn-danger" type="submit" value="Enviar"> 
            </form>
        </div>
    </div>
        </main>
        <footer>
            <!-- place footer here -->
        </footer>
        <!-- Bootstrap JavaScript Libraries -->
        

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        ></script>
    </body>
</html>
