<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Revisão HTML</title>
</head>
<body>
    <form methor="post" action="../">
    <!-- Menu -->
    <ul>
        <li><a href="cadastroprodutos.html">Cadastro de produtos</a></li>
        <li><a href="cadastroclientes.php">Cadastro de clientes</a></li>
        <li><a href="#">Cadastro de propriedades</a></li>
        <li><a href="#">Relatórios</a></li>
    </ul>
    <fieldset>
        <legend>Login</legend>
        <table>
            <tr>
                <td><label>Email:</label></td>
                <td><input type="email" name="email" required></td>
            </tr>
            <tr>
                <td><label>Senha:</label></td>
                <td><input type="password" name="senha" required></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="Entrar no sistema"></td>
            </tr>
        </table>
    </fieldset>
</form>
</body>
</html>